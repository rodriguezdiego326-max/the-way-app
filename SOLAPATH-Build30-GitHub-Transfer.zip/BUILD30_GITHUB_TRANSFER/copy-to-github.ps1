param(
    [Parameter(Mandatory=$true)]
    [string]$RepoPath
)

if (-not (Test-Path $RepoPath)) {
    Write-Error "Repository path does not exist: $RepoPath"
    exit 1
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$webSrc = Join-Path $ScriptDir "src\data\bible\web"
$webDst = Join-Path $RepoPath "src\data\bible\web"

if (-not (Test-Path $webDst)) {
    New-Item -ItemType Directory -Path $webDst -Force | Out-Null
}

Get-ChildItem -Path $webSrc -Filter *.json | ForEach-Object {
    $destFile = Join-Path $webDst $_.Name
    Copy-Item $_.FullName $destFile -Force
    Write-Host "Copied: $destFile"
}

$providerSrc = Join-Path $ScriptDir "src\lib\bibleProvider.ts"
$providerDstDir = Join-Path $RepoPath "src\lib"
if (-not (Test-Path $providerDstDir)) {
    New-Item -ItemType Directory -Path $providerDstDir -Force | Out-Null
}
$providerDst = Join-Path $providerDstDir "bibleProvider.ts"
Copy-Item $providerSrc $providerDst -Force
Write-Host "Copied: $providerDst"

$pbxSrc = Join-Path $ScriptDir "ios\App\App.xcodeproj\project.pbxproj"
$pbxDstDir = Join-Path $RepoPath "ios\App\App.xcodeproj"
if (-not (Test-Path $pbxDstDir)) {
    New-Item -ItemType Directory -Path $pbxDstDir -Force | Out-Null
}
$pbxDst = Join-Path $pbxDstDir "project.pbxproj"
Copy-Item $pbxSrc $pbxDst -Force
Write-Host "Copied: $pbxDst"

Write-Host ""
Write-Host "SUCCESS - Build 30 files copied to $RepoPath" -ForegroundColor Green
Write-Host "Use GitHub Desktop to commit and push."
