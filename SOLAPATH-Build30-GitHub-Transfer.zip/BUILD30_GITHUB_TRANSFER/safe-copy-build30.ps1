<#
.SYNOPSIS
  Safely copies approved Build 30 files into a cloned SOLAPATH GitHub repository.

.DESCRIPTION
  Default mode is DRY RUN - only displays what would change.
  Use -Apply to actually copy files.
  Creates a backup of any existing files before replacing them.
  Never deletes files. Never runs git commands.

.PARAMETER RepoPath
  Path to the cloned SOLAPATH GitHub repository on your Windows machine.

.PARAMETER Apply
  Switch flag. Without it, the script only does a dry run.

.EXAMPLE
  .\safe-copy-build30.ps1 -RepoPath "C:\Users\USER\Documents\GitHub\the-way-app"
  (Dry run - shows what would change, copies nothing)

.EXAMPLE
  .\safe-copy-build30.ps1 -RepoPath "C:\Users\USER\Documents\GitHub\the-way-app" -Apply
  (Copies files, backs up existing ones first)
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$RepoPath,

    [switch]$Apply
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ── 1. Verify RepoPath exists ──
if (-not (Test-Path $RepoPath)) {
    Write-Host "ERROR: Repository path does not exist: $RepoPath" -ForegroundColor Red
    exit 1
}

# ── 2. Verify RepoPath looks like the SOLAPATH repository ──
$repoChecks = @(
    "package.json",
    "src/App.tsx",
    "ios/App/App.xcodeproj/project.pbxproj"
)

$repoOk = $true
foreach ($check in $repoChecks) {
    $checkPath = Join-Path $RepoPath $check
    if (-not (Test-Path $checkPath)) {
        Write-Host "ERROR: Expected file not found in repository: $check" -ForegroundColor Red
        $repoOk = $false
    }
}
if (-not $repoOk) {
    Write-Host "ERROR: RepoPath does not appear to be the SOLAPATH repository. Stopping." -ForegroundColor Red
    exit 1
}

Write-Host "Repository verified: $RepoPath" -ForegroundColor Green

# ── 3. Verify source transfer files exist ──
$srcWebDir = Join-Path $ScriptDir "src\data\bible\web"
$srcProvider = Join-Path $ScriptDir "src\lib\bibleProvider.ts"
$srcPbxproj = Join-Path $ScriptDir "ios\App\App.xcodeproj\project.pbxproj"

if (-not (Test-Path (Join-Path $srcWebDir "index.json"))) {
    Write-Host "ERROR: Source index.json not found." -ForegroundColor Red
    exit 1
}
if (-not (Test-Path $srcProvider)) {
    Write-Host "ERROR: Source bibleProvider.ts not found." -ForegroundColor Red
    exit 1
}
if (-not (Test-Path $srcPbxproj)) {
    Write-Host "ERROR: Source project.pbxproj not found." -ForegroundColor Red
    exit 1
}

Write-Host "Source transfer files verified." -ForegroundColor Green

# ── 4. Count Bible JSON files ──
$jsonFiles = Get-ChildItem -Path $srcWebDir -Filter "*.json"
$jsonCount = $jsonFiles.Count

if ($jsonCount -ne 67) {
    Write-Host "ERROR: Expected 67 Bible JSON files, found $jsonCount. Stopping." -ForegroundColor Red
    exit 1
}

Write-Host "Bible JSON file count verified: $jsonCount" -ForegroundColor Green

# ── 5. Verify source project.pbxproj build settings ──
$pbxContent = Get-Content $srcPbxproj -Raw
$build30Count = ([regex]::Matches($pbxContent, "CURRENT_PROJECT_VERSION = 30;")).Count

if ($build30Count -lt 2) {
    Write-Host "ERROR: Expected CURRENT_PROJECT_VERSION = 30; at least twice, found $build30Count times. Stopping." -ForegroundColor Red
    exit 1
}
if ($pbxContent -notmatch "MARKETING_VERSION = 0\.1\.0;") {
    Write-Host "ERROR: MARKETING_VERSION = 0.1.0; not found in source project.pbxproj. Stopping." -ForegroundColor Red
    exit 1
}
if ($pbxContent -notmatch "PRODUCT_BUNDLE_IDENTIFIER = com\.rfgforge\.solapath;") {
    Write-Host "ERROR: PRODUCT_BUNDLE_IDENTIFIER = com.rfgforge.solapath; not found in source project.pbxproj. Stopping." -ForegroundColor Red
    exit 1
}

Write-Host "Source project.pbxproj build settings verified." -ForegroundColor Green

# ── 6. Determine what would be added vs replaced ──
$destWebDir = Join-Path $RepoPath "src\data\bible\web"
$destProvider = Join-Path $RepoPath "src\lib\bibleProvider.ts"
$destPbxproj = Join-Path $RepoPath "ios\App\App.xcodeproj\project.pbxproj"

$filesToAdd = @()
$filesToReplace = @()

# Bible JSON files
foreach ($jsonFile in $jsonFiles) {
    $destFile = Join-Path $destWebDir $jsonFile.Name
    if (Test-Path $destFile) {
        $filesToReplace += "src/data/bible/web/$($jsonFile.Name)"
    } else {
        $filesToAdd += "src/data/bible/web/$($jsonFile.Name)"
    }
}

# bibleProvider.ts
if (Test-Path $destProvider) {
    $filesToReplace += "src/lib/bibleProvider.ts"
} else {
    $filesToAdd += "src/lib/bibleProvider.ts"
}

# project.pbxproj
if (Test-Path $destPbxproj) {
    $filesToReplace += "ios/App/App.xcodeproj/project.pbxproj"
} else {
    $filesToAdd += "ios/App/App.xcodeproj/project.pbxproj"
}

# ── 7. Dry run output ──
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  BUILD 30 TRANSFER - DRY RUN REPORT" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "FILES TO ADD:" -ForegroundColor Yellow
if ($filesToAdd.Count -eq 0) {
    Write-Host "  (none)"
} else {
    foreach ($f in $filesToAdd) { Write-Host "  $f" }
}

Write-Host ""
Write-Host "FILES TO REPLACE:" -ForegroundColor Yellow
if ($filesToReplace.Count -eq 0) {
    Write-Host "  (none)"
} else {
    foreach ($f in $filesToReplace) { Write-Host "  $f" }
}

Write-Host ""
Write-Host "FILES TO DELETE:" -ForegroundColor Yellow
Write-Host "  NONE"

Write-Host ""
Write-Host "FILES OUTSIDE APPROVED PATHS:" -ForegroundColor Yellow
Write-Host "  NONE"

Write-Host ""
Write-Host "TOTAL BIBLE JSON FILES:" -ForegroundColor Yellow
Write-Host "  $jsonCount"

Write-Host ""
Write-Host "BIBLE PROVIDER:" -ForegroundColor Yellow
if (Test-Path $destProvider) { Write-Host "  REPLACE" } else { Write-Host "  ADD" }

Write-Host ""
Write-Host "PROJECT.PBXPROJ:" -ForegroundColor Yellow
if (Test-Path $destPbxproj) { Write-Host "  REPLACE" } else { Write-Host "  ADD" }

Write-Host ""

if (-not $Apply) {
    Write-Host "NO FILES HAVE BEEN CHANGED." -ForegroundColor Green
    Write-Host ""
    Write-Host "To apply these changes, run:" -ForegroundColor Cyan
    Write-Host "  .\safe-copy-build30.ps1 -RepoPath `"$RepoPath`" -Apply" -ForegroundColor White
    Write-Host ""
    exit 0
}

# ── 8. Apply: backup existing files that will be replaced ──
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = Join-Path $RepoPath "BUILD30_BACKUP_$timestamp"

$filesBackedUp = @()

foreach ($f in $filesToReplace) {
    $srcFile = Join-Path $RepoPath $f
    if (Test-Path $srcFile) {
        if (-not (Test-Path $backupDir)) {
            New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        }
        $backupFile = Join-Path $backupDir ($f -replace "[\\/]", "_")
        Copy-Item $srcFile $backupFile -Force
        $filesBackedUp += $f
    }
}

if ($filesBackedUp.Count -gt 0) {
    Write-Host "Backup created: $backupDir" -ForegroundColor Green
    foreach ($f in $filesBackedUp) {
        Write-Host "  Backed up: $f"
    }
} else {
    Write-Host "No existing files needed backup." -ForegroundColor Green
}

Write-Host ""

# ── 9. Apply: copy files ──

# Bible JSON files
if (-not (Test-Path $destWebDir)) {
    New-Item -ItemType Directory -Path $destWebDir -Force | Out-Null
}

foreach ($jsonFile in $jsonFiles) {
    $destFile = Join-Path $destWebDir $jsonFile.Name
    Copy-Item $jsonFile.FullName $destFile -Force
    Write-Host "Copied: src/data/bible/web/$($jsonFile.Name)"
}

# bibleProvider.ts
$destProviderDir = Join-Path $RepoPath "src\lib"
if (-not (Test-Path $destProviderDir)) {
    New-Item -ItemType Directory -Path $destProviderDir -Force | Out-Null
}
Copy-Item $srcProvider $destProvider -Force
Write-Host "Copied: src/lib/bibleProvider.ts"

# project.pbxproj
$destPbxDir = Join-Path $RepoPath "ios\App\App.xcodeproj"
if (-not (Test-Path $destPbxDir)) {
    New-Item -ItemType Directory -Path $destPbxDir -Force | Out-Null
}
Copy-Item $srcPbxproj $destPbxproj -Force
Write-Host "Copied: ios/App/App.xcodeproj/project.pbxproj"

Write-Host ""

# ── 10. Post-copy verification ──

$destJsonFiles = Get-ChildItem -Path $destWebDir -Filter "*.json"
$destJsonCount = $destJsonFiles.Count

if ($destJsonCount -ne 67) {
    Write-Host "ERROR: Post-copy verification failed. Expected 67 JSON files, found $destJsonCount." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $destProvider)) {
    Write-Host "ERROR: Post-copy verification failed. bibleProvider.ts not found at destination." -ForegroundColor Red
    exit 1
}

$destPbxContent = Get-Content $destPbxproj -Raw
$destBuild30Count = ([regex]::Matches($destPbxContent, "CURRENT_PROJECT_VERSION = 30;")).Count

if ($destBuild30Count -lt 2) {
    Write-Host "ERROR: Post-copy verification failed. CURRENT_PROJECT_VERSION = 30; not found twice." -ForegroundColor Red
    exit 1
}
if ($destPbxContent -notmatch "MARKETING_VERSION = 0\.1\.0;") {
    Write-Host "ERROR: Post-copy verification failed. MARKETING_VERSION = 0.1.0; not found." -ForegroundColor Red
    exit 1
}
if ($destPbxContent -notmatch "PRODUCT_BUNDLE_IDENTIFIER = com\.rfgforge\.solapath;") {
    Write-Host "ERROR: Post-copy verification failed. PRODUCT_BUNDLE_IDENTIFIER not found." -ForegroundColor Red
    exit 1
}

Write-Host "========================================" -ForegroundColor Green
Write-Host "  COPY COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Post-copy verification:" -ForegroundColor Cyan
Write-Host "  Bible JSON files: $destJsonCount"
Write-Host "  bibleProvider.ts:  YES"
Write-Host "  project.pbxproj:   YES"
Write-Host ""
Write-Host "  DEBUG BUILD:        30"
Write-Host "  RELEASE BUILD:     30"
Write-Host "  MARKETING VERSION:  0.1.0"
Write-Host "  BUNDLE:             com.rfgforge.solapath"
Write-Host ""
Write-Host "Backup directory: $backupDir" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Open GitHub Desktop"
Write-Host "  2. Review the changed files"
Write-Host "  3. Commit with message: Build 30 - restore local Bible data"
Write-Host "  4. Push to origin/main"
Write-Host ""
