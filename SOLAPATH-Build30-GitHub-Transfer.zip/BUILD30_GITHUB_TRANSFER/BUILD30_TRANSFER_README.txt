SOLAPATH BUILD 30 — GITHUB TRANSFER

COPY THESE FILES INTO THE ROOT OF THE SOLAPATH GITHUB REPOSITORY.

Required additions:

src/data/bible/web/
src/lib/bibleProvider.ts

Required replacement:

ios/App/App.xcodeproj/project.pbxproj

Expected build:

MARKETING VERSION:
0.1.0

DEBUG BUILD:
30

RELEASE BUILD:
30

BUNDLE:
com.rfgforge.solapath

Expected Bible JSON count:
67

DO NOT copy:
node_modules
dist
.git
temporary files

After copying, commit to GitHub main with:

Build 30 - restore local Bible data

Then push origin.
